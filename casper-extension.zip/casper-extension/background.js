const CASPER_SERVER_URL = "http://127.0.0.1:6800";

// Setup context menus on installation
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "casper-download-link",
    title: "Download with Casper",
    contexts: ["link", "video", "audio", "image"]
  });
  console.log("[Casper Extension] Initialized context menu and background service worker.");
});

// Helper to check if Casper Desktop App server is alive
async function isCasperServerAlive() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1000);
    const response = await fetch(`${CASPER_SERVER_URL}/ping`, {
      method: "GET",
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    return response.ok;
  } catch (err) {
    return false;
  }
}

// Helper to extract cookies formatted as "name=value; name2=value2"
async function getCookiesForUrl(url) {
  try {
    const cookieMap = new Map();

    // 1. Get cookies strictly matching the URL if valid HTTP(S)
    if (url && (url.startsWith("http://") || url.startsWith("https://"))) {
      try {
        const urlCookies = await chrome.cookies.getAll({ url: url });
        for (const c of urlCookies) {
          cookieMap.set(c.name, c.value);
        }
      } catch (e) {
        console.warn("[Casper Extension] Could not query exact URL cookies:", e);
      }
    }

    // 2. If it is YouTube or Google domain, include all session tokens
    if (url && (url.includes("google.com") || url.includes("googleusercontent.com") || url.includes("youtube.com") || url.includes("youtu.be"))) {
      try {
        const youtubeCookies = await chrome.cookies.getAll({ domain: ".youtube.com" });
        for (const c of youtubeCookies) {
          if (!cookieMap.has(c.name)) {
            cookieMap.set(c.name, c.value);
          }
        }
      } catch (e) {}

      try {
        const googleCookies = await chrome.cookies.getAll({ domain: ".google.com" });
        for (const c of googleCookies) {
          if (!cookieMap.has(c.name)) {
            cookieMap.set(c.name, c.value);
          }
        }
      } catch (e) {}

      try {
        const driveCookies = await chrome.cookies.getAll({ domain: "drive.google.com" });
        for (const c of driveCookies) {
          if (!cookieMap.has(c.name)) {
            cookieMap.set(c.name, c.value);
          }
        }
      } catch (e) {}

      try {
        const userContentCookies = await chrome.cookies.getAll({ domain: ".googleusercontent.com" });
        for (const c of userContentCookies) {
          if (!cookieMap.has(c.name)) {
            cookieMap.set(c.name, c.value);
          }
        }
      } catch (e) {}

      try {
        const accountsCookies = await chrome.cookies.getAll({ domain: "accounts.google.com" });
        for (const c of accountsCookies) {
          if (!cookieMap.has(c.name)) {
            cookieMap.set(c.name, c.value);
          }
        }
      } catch (e) {}
    }

    if (cookieMap.size === 0) {
      return null;
    }

    const cookieParts = [];
    for (const [name, val] of cookieMap.entries()) {
      cookieParts.push(`${name}=${val}`);
    }
    return cookieParts.join("; ");
  } catch (err) {
    console.warn("[Casper Extension] Cookie extraction warning:", err);
    return null;
  }
}

// Send download task to Casper Desktop Native Engine
async function sendToCasper(downloadData) {
  try {
    const payload = {
      url: downloadData.url,
      suggestedName: downloadData.suggestedName || null,
      cookies: downloadData.cookies || null,
      userAgent: downloadData.userAgent || navigator.userAgent,
      referer: downloadData.referer || null
    };

    console.log("[Casper Extension] Sending download to Casper Desktop:", payload.url);

    // Using text/plain is CORS-safelisted: it never triggers preflight OPTIONS!
    const response = await fetch(`${CASPER_SERVER_URL}/add`, {
      method: "POST",
      headers: {
        "Content-Type": "text/plain"
      },
      body: JSON.stringify(payload)
    });

    const isOk = response.ok;
    console.log("[Casper Extension] Casper Server response status:", response.status, isOk);
    return isOk;
  } catch (err) {
    console.error("[Casper Extension] Network error sending to Casper:", err);
    return false;
  }
}

// Intercept browser downloads
chrome.downloads.onCreated.addListener(async (downloadItem) => {
  const settings = await chrome.storage.local.get({ autoCatch: true });
  if (!settings.autoCatch) {
    return;
  }

  const url = downloadItem.url || downloadItem.finalUrl;
  if (!url || url.startsWith("blob:") || url.startsWith("data:") || url.startsWith("chrome://")) {
    return;
  }

  // Check if Casper Desktop app is running
  const alive = await isCasperServerAlive();
  if (!alive) {
    console.log("[Casper Extension] Casper Desktop is offline. Allowing browser download.");
    return;
  }

  // Extract cookies and active tab info
  const cookies = await getCookiesForUrl(url);
  let referer = downloadItem.referrer || "";
  if (!referer) {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs && tabs[0] && tabs[0].url) {
        referer = tabs[0].url;
      }
    } catch (e) {}
  }

  let suggestedName = downloadItem.filename ? downloadItem.filename.split(/[\/\\]/).pop() : null;

  try {
    const ok = await sendToCasper({
      url: url,
      suggestedName: suggestedName,
      cookies: cookies,
      userAgent: navigator.userAgent,
      referer: referer
    });

    if (ok) {
      console.log("[Casper Extension] Handled by Casper. Cancelling browser download.");
      try {
        await chrome.downloads.cancel(downloadItem.id);
        await chrome.downloads.erase({ id: downloadItem.id });
      } catch (cancelErr) {
        // Ignored if cancelling not allowed yet
      }
    }
  } catch (err) {
    console.error("[Casper Extension] Intercept failure:", err);
  }
});

// Handle Context Menu click
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "casper-download-link") {
    let targetUrl = info.linkUrl || info.srcUrl || tab?.url;
    if (targetUrl && targetUrl.startsWith("blob:")) {
      targetUrl = tab?.url || "";
    }
    if (!targetUrl || targetUrl.startsWith("chrome://") || targetUrl.startsWith("edge://") || targetUrl.startsWith("blob:")) {
      return;
    }

    const alive = await isCasperServerAlive();
    if (!alive) {
      alert("Casper Download Manager is not running. Please start the Casper desktop app first.");
      return;
    }

    const cookies = await getCookiesForUrl(targetUrl);
    await sendToCasper({
      url: targetUrl,
      cookies: cookies,
      userAgent: navigator.userAgent,
      referer: tab?.url || ""
    });
  }
});

// Handle messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "ping") {
    isCasperServerAlive().then((alive) => {
      sendResponse({ alive });
    });
    return true;
  }

  if (request.action === "sendUrl") {
    (async () => {
      try {
        console.log("[Casper Extension] Popup requested sendUrl:", request.url);
        const cookies = await getCookiesForUrl(request.url);
        const ok = await sendToCasper({
          url: request.url,
          cookies: cookies,
          userAgent: navigator.userAgent,
          referer: request.referer || ""
        });
        sendResponse({ success: ok });
      } catch (e) {
        console.error("[Casper Extension] sendUrl error:", e);
        sendResponse({ success: false });
      }
    })();
    return true;
  }
});
