const statusDot = document.getElementById("statusDot");
const statusText = document.getElementById("statusText");
const autoCatchToggle = document.getElementById("autoCatchToggle");
const urlInput = document.getElementById("urlInput");
const sendBtn = document.getElementById("sendBtn");

// 1. Load saved preferences
chrome.storage.local.get({ autoCatch: true }, (items) => {
  autoCatchToggle.checked = items.autoCatch;
});

autoCatchToggle.addEventListener("change", () => {
  chrome.storage.local.set({ autoCatch: autoCatchToggle.checked });
});

// 2. Check Casper Desktop Engine Status
async function checkStatus() {
  chrome.runtime.sendMessage({ action: "ping" }, (response) => {
    if (chrome.runtime.lastError || !response || !response.alive) {
      statusDot.className = "status-dot";
      statusText.className = "status-text";
      statusText.textContent = "Desktop App Offline";
      sendBtn.disabled = true;
    } else {
      statusDot.className = "status-dot online";
      statusText.className = "status-text online";
      statusText.textContent = "Connected (Port 6800)";
      sendBtn.disabled = false;
    }
  });
}

checkStatus();
const statusInterval = setInterval(checkStatus, 3000);

// 3. Pre-fill active tab URL if relevant
let currentTabUrl = "";
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (tabs && tabs[0] && tabs[0].url) {
    currentTabUrl = tabs[0].url;
    if (
      currentTabUrl.includes("drive.google.com") ||
      currentTabUrl.includes("mediafire.com") ||
      currentTabUrl.includes("dropbox.com") ||
      currentTabUrl.match(/\.(zip|rar|7z|exe|iso|mp4|mkv|tar|gz)$/i)
    ) {
      urlInput.value = currentTabUrl;
    }
  }
});

// 4. Send URL button handler
sendBtn.addEventListener("click", () => {
  const url = urlInput.value.trim();
  if (!url) return;

  sendBtn.textContent = "Sending...";
  sendBtn.disabled = true;

  chrome.runtime.sendMessage({ action: "sendUrl", url: url, referer: currentTabUrl }, (res) => {
    sendBtn.disabled = false;
    if (res && res.success) {
      sendBtn.textContent = "Sent!";
      setTimeout(() => {
        sendBtn.textContent = "Send";
        urlInput.value = "";
      }, 1500);
    } else {
      sendBtn.textContent = "Failed";
      setTimeout(() => {
        sendBtn.textContent = "Send";
      }, 1500);
    }
  });
});
